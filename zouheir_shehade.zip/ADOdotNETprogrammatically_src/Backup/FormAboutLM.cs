using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace LIBManager
{
	/// <summary>
	/// Summary description for Formabout.
	/// </summary>
	public class FormAboutLM : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.Label labelVersion;
		private System.Windows.Forms.Label labelCR;
		private System.Windows.Forms.Label labelDesc;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FormAboutLM()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormAboutLM));
			this.labelTitle = new System.Windows.Forms.Label();
			this.labelVersion = new System.Windows.Forms.Label();
			this.labelCR = new System.Windows.Forms.Label();
			this.labelDesc = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(0)));
			this.labelTitle.Location = new System.Drawing.Point(74, 24);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(208, 32);
			this.labelTitle.TabIndex = 1;
			this.labelTitle.Text = "Library Manager";
			this.labelTitle.Click += new System.EventHandler(this.Formabout_Click);
			// 
			// labelVersion
			// 
			this.labelVersion.BackColor = System.Drawing.Color.Transparent;
			this.labelVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.labelVersion.Location = new System.Drawing.Point(128, 56);
			this.labelVersion.Name = "labelVersion";
			this.labelVersion.Size = new System.Drawing.Size(100, 16);
			this.labelVersion.TabIndex = 2;
			this.labelVersion.Text = "Version 1.0.2.4";
			this.labelVersion.Click += new System.EventHandler(this.Formabout_Click);
			// 
			// labelCR
			// 
			this.labelCR.BackColor = System.Drawing.Color.Transparent;
			this.labelCR.Location = new System.Drawing.Point(24, 192);
			this.labelCR.Name = "labelCR";
			this.labelCR.Size = new System.Drawing.Size(304, 16);
			this.labelCR.TabIndex = 5;
			this.labelCR.Text = "(c) 2005 Library Manager Version 1.0.2.4 by L-NRG";
			this.labelCR.Click += new System.EventHandler(this.Formabout_Click);
			// 
			// labelDesc
			// 
			this.labelDesc.BackColor = System.Drawing.Color.Transparent;
			this.labelDesc.ForeColor = System.Drawing.Color.Black;
			this.labelDesc.Location = new System.Drawing.Point(80, 120);
			this.labelDesc.Name = "labelDesc";
			this.labelDesc.Size = new System.Drawing.Size(192, 64);
			this.labelDesc.TabIndex = 6;
			this.labelDesc.Text = "Library Manager help you hold the basic information about your books.";
			this.labelDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.labelDesc.Click += new System.EventHandler(this.Formabout_Click);
			// 
			// FormAboutLM
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(350, 232);
			this.Controls.Add(this.labelDesc);
			this.Controls.Add(this.labelCR);
			this.Controls.Add(this.labelVersion);
			this.Controls.Add(this.labelTitle);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "FormAboutLM";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "About";
			this.Click += new System.EventHandler(this.Formabout_Click);
			this.ResumeLayout(false);

		}
		#endregion

		private void Formabout_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void textBoxDesc_TextChanged(object sender, System.EventArgs e)
		{
		
		}
	}
}
