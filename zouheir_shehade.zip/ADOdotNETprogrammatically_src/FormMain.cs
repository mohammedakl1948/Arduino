using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace LIBManager
{
	
	public class FormMain : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ToolBar toolBar1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.ToolBarButton toolBarButtonexit;
		private System.Windows.Forms.ImageList buttonimageList;
		private System.Windows.Forms.ToolBarButton toolBarButtonplus;
		private System.Windows.Forms.ToolBarButton toolBarButtonminus;
		private System.Windows.Forms.ToolBarButton toolBarButtonsearch;
		private System.Windows.Forms.ToolBarButton toolBarButtonsplit;
		private System.Windows.Forms.ToolBarButton toolBarButtonmodify;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.StatusBarPanel statusBarPanelgeneral;
		private System.Windows.Forms.StatusBarPanel statusBarPaneldateandtime;
		private System.Windows.Forms.GroupBox groupBox;
		private System.Windows.Forms.StatusBar statusBar;
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.GroupBox groupBoxtextboxes;
		private System.Windows.Forms.Label labeltitle;
		private System.Windows.Forms.Label labelauthor;
		private System.Windows.Forms.Label labelpage;
		private System.Windows.Forms.Label labeltopic;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.DataGrid dataGrid;
		private System.Windows.Forms.TextBox textBoxTopic;
		private System.Windows.Forms.TextBox textBoxPage;
		private System.Windows.Forms.TextBox textBoxAuthor;
		private System.Windows.Forms.TextBox textBoxTitle;
		private System.Windows.Forms.TextBox textBoxCode;
		private System.Windows.Forms.Label labelCode;

		
		dataManipulationClass cDataMan=new dataManipulationClass();

		private System.Windows.Forms.MenuItem menuItemExit;
		private System.Windows.Forms.MenuItem menuItemAdd;
		private System.Windows.Forms.MenuItem menuItemDelete;
		private System.Windows.Forms.MenuItem menuItemModify;
		private System.Windows.Forms.MenuItem menuItemSearch;
		private System.Windows.Forms.MenuItem menuItemAbout;
		private System.Windows.Forms.ToolBarButton toolBarButtonReload;
		private System.Windows.Forms.MenuItem menuItemreload;
		private System.Windows.Forms.ToolBarButton toolBarButtonsplit0;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuCreateDatabase;
		private System.Windows.Forms.Timer timer;

		public FormMain()
		{
			
			InitializeComponent();

			
		}

		
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormMain));
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItemExit = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItemreload = new System.Windows.Forms.MenuItem();
			this.menuItemAdd = new System.Windows.Forms.MenuItem();
			this.menuItemDelete = new System.Windows.Forms.MenuItem();
			this.menuItemModify = new System.Windows.Forms.MenuItem();
			this.menuItemSearch = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuCreateDatabase = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItemAbout = new System.Windows.Forms.MenuItem();
			this.toolBar1 = new System.Windows.Forms.ToolBar();
			this.toolBarButtonsplit0 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonReload = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonplus = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonminus = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonsearch = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonmodify = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonsplit = new System.Windows.Forms.ToolBarButton();
			this.toolBarButtonexit = new System.Windows.Forms.ToolBarButton();
			this.buttonimageList = new System.Windows.Forms.ImageList(this.components);
			this.statusBar = new System.Windows.Forms.StatusBar();
			this.statusBarPanelgeneral = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPaneldateandtime = new System.Windows.Forms.StatusBarPanel();
			this.groupBox = new System.Windows.Forms.GroupBox();
			this.dataGrid = new System.Windows.Forms.DataGrid();
			this.groupBoxtextboxes = new System.Windows.Forms.GroupBox();
			this.labelCode = new System.Windows.Forms.Label();
			this.textBoxCode = new System.Windows.Forms.TextBox();
			this.labeltopic = new System.Windows.Forms.Label();
			this.labelpage = new System.Windows.Forms.Label();
			this.labelauthor = new System.Windows.Forms.Label();
			this.labeltitle = new System.Windows.Forms.Label();
			this.textBoxTopic = new System.Windows.Forms.TextBox();
			this.textBoxPage = new System.Windows.Forms.TextBox();
			this.textBoxAuthor = new System.Windows.Forms.TextBox();
			this.textBoxTitle = new System.Windows.Forms.TextBox();
			this.timer = new System.Windows.Forms.Timer(this.components);
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelgeneral)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPaneldateandtime)).BeginInit();
			this.groupBox.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
			this.groupBoxtextboxes.SuspendLayout();
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuItem1,
																					 this.menuItem5,
																					 this.menuItem4,
																					 this.menuItem3});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem2,
																					  this.menuItemExit});
			this.menuItem1.Text = "File";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "-";
			// 
			// menuItemExit
			// 
			this.menuItemExit.Index = 1;
			this.menuItemExit.Shortcut = System.Windows.Forms.Shortcut.CtrlE;
			this.menuItemExit.Text = "E&xit";
			this.menuItemExit.Click += new System.EventHandler(this.menuItemexit_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 1;
			this.menuItem5.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItemreload,
																					  this.menuItemAdd,
																					  this.menuItemDelete,
																					  this.menuItemModify,
																					  this.menuItemSearch});
			this.menuItem5.Text = "Actions";
			// 
			// menuItemreload
			// 
			this.menuItemreload.Index = 0;
			this.menuItemreload.Shortcut = System.Windows.Forms.Shortcut.CtrlR;
			this.menuItemreload.Text = "&Reload All Records ";
			this.menuItemreload.Click += new System.EventHandler(this.menuItemreload_Click);
			// 
			// menuItemAdd
			// 
			this.menuItemAdd.Index = 1;
			this.menuItemAdd.Shortcut = System.Windows.Forms.Shortcut.CtrlA;
			this.menuItemAdd.Text = "&Add Record";
			this.menuItemAdd.Click += new System.EventHandler(this.menuItemAdd_Click);
			// 
			// menuItemDelete
			// 
			this.menuItemDelete.Index = 2;
			this.menuItemDelete.Shortcut = System.Windows.Forms.Shortcut.CtrlD;
			this.menuItemDelete.Text = "&Delete Record";
			this.menuItemDelete.Click += new System.EventHandler(this.menuItemDelete_Click);
			// 
			// menuItemModify
			// 
			this.menuItemModify.Index = 3;
			this.menuItemModify.Shortcut = System.Windows.Forms.Shortcut.CtrlM;
			this.menuItemModify.Text = "&Modify Record";
			this.menuItemModify.Click += new System.EventHandler(this.menuItemModify_Click);
			// 
			// menuItemSearch
			// 
			this.menuItemSearch.Index = 4;
			this.menuItemSearch.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
			this.menuItemSearch.Text = "&Search Record";
			this.menuItemSearch.Click += new System.EventHandler(this.menuItemSearch_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 2;
			this.menuItem4.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuCreateDatabase});
			this.menuItem4.Text = "Settings";
			// 
			// menuCreateDatabase
			// 
			this.menuCreateDatabase.Index = 0;
			this.menuCreateDatabase.Text = "Create Database";
			this.menuCreateDatabase.Click += new System.EventHandler(this.menuCreateDatabase_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 3;
			this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItemAbout});
			this.menuItem3.Text = "Help";
			// 
			// menuItemAbout
			// 
			this.menuItemAbout.Index = 0;
			this.menuItemAbout.Text = "About";
			this.menuItemAbout.Click += new System.EventHandler(this.menuItemAbout_Click);
			// 
			// toolBar1
			// 
			this.toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						this.toolBarButtonsplit0,
																						this.toolBarButtonReload,
																						this.toolBarButtonplus,
																						this.toolBarButtonminus,
																						this.toolBarButtonsearch,
																						this.toolBarButtonmodify,
																						this.toolBarButtonsplit,
																						this.toolBarButtonexit});
			this.toolBar1.DropDownArrows = true;
			this.toolBar1.ImageList = this.buttonimageList;
			this.toolBar1.Location = new System.Drawing.Point(0, 0);
			this.toolBar1.Name = "toolBar1";
			this.toolBar1.ShowToolTips = true;
			this.toolBar1.Size = new System.Drawing.Size(594, 52);
			this.toolBar1.TabIndex = 0;
			this.toolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
			// 
			// toolBarButtonsplit0
			// 
			this.toolBarButtonsplit0.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// toolBarButtonReload
			// 
			this.toolBarButtonReload.ImageIndex = 6;
			this.toolBarButtonReload.Tag = "reload";
			this.toolBarButtonReload.ToolTipText = "Reload";
			// 
			// toolBarButtonplus
			// 
			this.toolBarButtonplus.ImageIndex = 0;
			this.toolBarButtonplus.Tag = "plus";
			this.toolBarButtonplus.ToolTipText = "Add";
			// 
			// toolBarButtonminus
			// 
			this.toolBarButtonminus.ImageIndex = 2;
			this.toolBarButtonminus.Tag = "minus";
			this.toolBarButtonminus.ToolTipText = "Delete";
			// 
			// toolBarButtonsearch
			// 
			this.toolBarButtonsearch.ImageIndex = 5;
			this.toolBarButtonsearch.Tag = "search";
			this.toolBarButtonsearch.ToolTipText = "Search";
			// 
			// toolBarButtonmodify
			// 
			this.toolBarButtonmodify.ImageIndex = 3;
			this.toolBarButtonmodify.Tag = "modify";
			this.toolBarButtonmodify.ToolTipText = "Modify";
			// 
			// toolBarButtonsplit
			// 
			this.toolBarButtonsplit.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// toolBarButtonexit
			// 
			this.toolBarButtonexit.ImageIndex = 1;
			this.toolBarButtonexit.Tag = "exit";
			this.toolBarButtonexit.ToolTipText = "Exit";
			// 
			// buttonimageList
			// 
			this.buttonimageList.ImageSize = new System.Drawing.Size(40, 40);
			this.buttonimageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("buttonimageList.ImageStream")));
			this.buttonimageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// statusBar
			// 
			this.statusBar.Location = new System.Drawing.Point(0, 393);
			this.statusBar.Name = "statusBar";
			this.statusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						 this.statusBarPanelgeneral,
																						 this.statusBarPaneldateandtime});
			this.statusBar.ShowPanels = true;
			this.statusBar.Size = new System.Drawing.Size(594, 24);
			this.statusBar.TabIndex = 1;
			// 
			// statusBarPanelgeneral
			// 
			this.statusBarPanelgeneral.MinWidth = 100;
			this.statusBarPanelgeneral.Text = "Library Manager";
			this.statusBarPanelgeneral.Width = 500;
			// 
			// statusBarPaneldateandtime
			// 
			this.statusBarPaneldateandtime.Text = "Current date&time";
			this.statusBarPaneldateandtime.Width = 150;
			// 
			// groupBox
			// 
			this.groupBox.Controls.Add(this.dataGrid);
			this.groupBox.Controls.Add(this.groupBoxtextboxes);
			this.groupBox.Location = new System.Drawing.Point(9, 55);
			this.groupBox.Name = "groupBox";
			this.groupBox.Size = new System.Drawing.Size(577, 334);
			this.groupBox.TabIndex = 2;
			this.groupBox.TabStop = false;
			// 
			// dataGrid
			// 
			this.dataGrid.AlternatingBackColor = System.Drawing.SystemColors.InactiveBorder;
			this.dataGrid.CaptionText = "Books";
			this.dataGrid.DataMember = "";
			this.dataGrid.GridLineColor = System.Drawing.SystemColors.ControlDark;
			this.dataGrid.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
			this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid.ImeMode = System.Windows.Forms.ImeMode.KatakanaHalf;
			this.dataGrid.Location = new System.Drawing.Point(8, 112);
			this.dataGrid.Name = "dataGrid";
			this.dataGrid.PreferredColumnWidth = 90;
			this.dataGrid.ReadOnly = true;
			this.dataGrid.Size = new System.Drawing.Size(560, 208);
			this.dataGrid.TabIndex = 1;
			this.dataGrid.TabStop = false;
			this.dataGrid.Click += new System.EventHandler(this.dataGrid_CurrentCellChanged);
			this.dataGrid.CurrentCellChanged += new System.EventHandler(this.dataGrid_CurrentCellChanged);
			// 
			// groupBoxtextboxes
			// 
			this.groupBoxtextboxes.Controls.Add(this.labelCode);
			this.groupBoxtextboxes.Controls.Add(this.textBoxCode);
			this.groupBoxtextboxes.Controls.Add(this.labeltopic);
			this.groupBoxtextboxes.Controls.Add(this.labelpage);
			this.groupBoxtextboxes.Controls.Add(this.labelauthor);
			this.groupBoxtextboxes.Controls.Add(this.labeltitle);
			this.groupBoxtextboxes.Controls.Add(this.textBoxTopic);
			this.groupBoxtextboxes.Controls.Add(this.textBoxPage);
			this.groupBoxtextboxes.Controls.Add(this.textBoxAuthor);
			this.groupBoxtextboxes.Controls.Add(this.textBoxTitle);
			this.groupBoxtextboxes.Location = new System.Drawing.Point(8, 8);
			this.groupBoxtextboxes.Name = "groupBoxtextboxes";
			this.groupBoxtextboxes.Size = new System.Drawing.Size(560, 96);
			this.groupBoxtextboxes.TabIndex = 0;
			this.groupBoxtextboxes.TabStop = false;
			this.groupBoxtextboxes.Text = "Edit";
			// 
			// labelCode
			// 
			this.labelCode.Location = new System.Drawing.Point(400, 57);
			this.labelCode.Name = "labelCode";
			this.labelCode.Size = new System.Drawing.Size(32, 20);
			this.labelCode.TabIndex = 16;
			this.labelCode.Text = "Code";
			// 
			// textBoxCode
			// 
			this.textBoxCode.Location = new System.Drawing.Point(440, 56);
			this.textBoxCode.Name = "textBoxCode";
			this.textBoxCode.Size = new System.Drawing.Size(88, 20);
			this.textBoxCode.TabIndex = 4;
			this.textBoxCode.Text = "";
			// 
			// labeltopic
			// 
			this.labeltopic.Location = new System.Drawing.Point(296, 25);
			this.labeltopic.Name = "labeltopic";
			this.labeltopic.Size = new System.Drawing.Size(40, 20);
			this.labeltopic.TabIndex = 14;
			this.labeltopic.Text = "Topic";
			// 
			// labelpage
			// 
			this.labelpage.Location = new System.Drawing.Point(296, 57);
			this.labelpage.Name = "labelpage";
			this.labelpage.Size = new System.Drawing.Size(40, 20);
			this.labelpage.TabIndex = 13;
			this.labelpage.Text = "Page";
			// 
			// labelauthor
			// 
			this.labelauthor.Location = new System.Drawing.Point(8, 57);
			this.labelauthor.Name = "labelauthor";
			this.labelauthor.Size = new System.Drawing.Size(56, 20);
			this.labelauthor.TabIndex = 12;
			this.labelauthor.Text = "Author";
			// 
			// labeltitle
			// 
			this.labeltitle.Location = new System.Drawing.Point(8, 26);
			this.labeltitle.Name = "labeltitle";
			this.labeltitle.Size = new System.Drawing.Size(56, 20);
			this.labeltitle.TabIndex = 11;
			this.labeltitle.Text = "Book Title";
			// 
			// textBoxTopic
			// 
			this.textBoxTopic.Location = new System.Drawing.Point(336, 24);
			this.textBoxTopic.Name = "textBoxTopic";
			this.textBoxTopic.Size = new System.Drawing.Size(192, 20);
			this.textBoxTopic.TabIndex = 2;
			this.textBoxTopic.Text = "";
			// 
			// textBoxPage
			// 
			this.textBoxPage.Location = new System.Drawing.Point(336, 56);
			this.textBoxPage.Name = "textBoxPage";
			this.textBoxPage.Size = new System.Drawing.Size(48, 20);
			this.textBoxPage.TabIndex = 3;
			this.textBoxPage.Text = "";
			// 
			// textBoxAuthor
			// 
			this.textBoxAuthor.Location = new System.Drawing.Point(65, 56);
			this.textBoxAuthor.Name = "textBoxAuthor";
			this.textBoxAuthor.Size = new System.Drawing.Size(200, 20);
			this.textBoxAuthor.TabIndex = 1;
			this.textBoxAuthor.Text = "";
			// 
			// textBoxTitle
			// 
			this.textBoxTitle.Location = new System.Drawing.Point(65, 24);
			this.textBoxTitle.Name = "textBoxTitle";
			this.textBoxTitle.Size = new System.Drawing.Size(200, 20);
			this.textBoxTitle.TabIndex = 0;
			this.textBoxTitle.Text = "";
			// 
			// timer
			// 
			this.timer.Enabled = true;
			this.timer.Interval = 1000;
			this.timer.Tick += new System.EventHandler(this.timer_Tick);
			// 
			// FormMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(594, 417);
			this.Controls.Add(this.groupBox);
			this.Controls.Add(this.statusBar);
			this.Controls.Add(this.toolBar1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Menu = this.mainMenu;
			this.Name = "FormMain";
			this.Text = "Library Manager";
			this.Load += new System.EventHandler(this.FormMain_Load);
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanelgeneral)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPaneldateandtime)).EndInit();
			this.groupBox.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
			this.groupBoxtextboxes.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		
		[STAThread]
		static void Main() 
		{
			Application.Run(new FormMain());
		}

		private void menuItemExit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void toolBar1_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			switch(e.Button.Tag.ToString())
			{
				case "exit" :
                    this.Close();
					break;
				case "plus":
					AddData();
					break;
				case "minus":
					DeleteData();
					break;
				case "search":
					SearchData();
					break;
				case "modify":
					ModifyData();
					break;
				case "reload":
					LoadData();
					break;
				default:
					break;
			}
		}
			
		private void menuItemAbout_Click(object sender, System.EventArgs e)
		{
			FormAboutLM fabout=new FormAboutLM();
			fabout.ShowDialog();
		}

		private void FormMain_Load(object sender, System.EventArgs e)
		{
			LoadData();
		}

		
		public void LoadData()
		{
			
			cDataMan.ManupulateData();
			
			dataGrid.DataSource=cDataMan.myds;
			
			dataGrid.DataMember="books";		
			try
			{
				
				cDataMan.myadap.Fill(cDataMan.mytable);
			}
			catch(Exception xcp)
			{
				
				MessageBox.Show(xcp.ToString());
			}
			finally
			{
				
				cDataMan.mycon.Close();
			}
		}

		
		public void AddData()
		{
			
			
			string sTitle=textBoxTitle.Text.ToString();
			string sAuthor=textBoxAuthor.Text.ToString();
			int sPageCount=0;
			if(textBoxPage.Text!="")
			{
				try
				{
					sPageCount=Convert.ToInt32(textBoxPage.Text);
				}
				catch
				{
				}
			}

			string sTopic=textBoxTopic.Text.ToString();
			string sCode=textBoxCode.Text.ToString();

			
			cDataMan.mycomm.CommandText="INSERT INTO BOOKS (TITLE,AUTHOR,PAGECOUNT,"
				+"TOPIC,CODE) VALUES(@Title, @Author, @PageCount, @Topic, @Code);";

			
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@Title",sTitle));
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@Author",sAuthor));
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@PageCount",sPageCount));
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@Topic",sTopic));
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@Code",sCode));

			try
			{
				
				cDataMan.mycon.Open();
				
				cDataMan.mycomm.ExecuteNonQuery();
			}
			catch(Exception exc)
			{
				
				MessageBox.Show(exc.ToString());
			}
			finally
			{
				
				cDataMan.mycon.Close();
				
			}
			
			LoadData();
		}

		
		public void DeleteData()
		{
			int iDataGridRow=dataGrid.CurrentCell.RowNumber;
			string sBookID=dataGrid[iDataGridRow,0].ToString().Trim();


			
			cDataMan.ManupulateData();
			
			cDataMan.mycomm.CommandText="DELETE FROM BOOKS WHERE BOOKID=@BookID";
			
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@BookID",sBookID));

			try
			{
				
				cDataMan.mycon.Open();
				
				cDataMan.mycomm.ExecuteNonQuery();
			}
			catch(Exception xcp)
			{
				
				MessageBox.Show(xcp.ToString());
			}
			finally
			{
				
				cDataMan.mycon.Close();
			}	
			
			LoadData();
		}

		
		private void SearchData()
		{
			string sTitle=textBoxTitle.Text.ToString();

			
			cDataMan.ManupulateData();

			
			cDataMan.mycomm.CommandText="SELECT TITLE,AUTHOR,PAGECOUNT,"
				+"TOPIC,CODE FROM BOOKS WHERE TITLE=@Title";

			
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@Title",sTitle));

		
			dataGrid.DataSource=cDataMan.myds;
			try
			{
				
				cDataMan.myadap.Fill(cDataMan.mytable);
			}
			catch(Exception xcp)
			{
				
				MessageBox.Show(xcp.ToString());
			}
			finally
			{
				
				cDataMan.mycon.Close();
			}	
		}

		
		public void ModifyData()
		{
		
			int iDataGridRow=dataGrid.CurrentCell.RowNumber;
			string sBookID=dataGrid[iDataGridRow,0].ToString().Trim();

		
			string sTitle=textBoxTitle.Text.ToString().Trim();
			string sAuthor=textBoxAuthor.Text.ToString();
			int sPageCount=Convert.ToInt32(textBoxPage.Text.ToString());
			string sTopic=textBoxTopic.Text.ToString();
			string sCode=textBoxCode.Text.ToString();

			
			cDataMan.ManupulateData();

		
			cDataMan.mycomm.CommandText="UPDATE BOOKS SET TITLE=@Title,AUTHOR=@Author,"
				+"PAGECOUNT=@PageCount,TOPIC=@Topic,CODE=@Code  WHERE BOOKID=@BookID;";

			
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@BookID",sBookID));
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@Title",sTitle));
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@Author",sAuthor));
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@PageCount",sPageCount));
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@Topic",sTopic));
			cDataMan.mycomm.Parameters.Add(new SqlParameter("@Code",sCode));


			try
			{
				
				cDataMan.mycon.Open();
				
				cDataMan.mycomm.ExecuteNonQuery();
			}
			catch(Exception exc)
			{
				
				MessageBox.Show(exc.ToString());
			}
			finally
			{
				
				cDataMan.mycon.Close();
			}	
		
			LoadData();	
		}

		
		private void dataGrid_CurrentCellChanged(object sender, System.EventArgs e)
		{
          
            dataGrid.Select(dataGrid.CurrentCell.RowNumber);

		
			int iDataGridRow=dataGrid.CurrentCell.RowNumber;
			textBoxTitle.Text=dataGrid[iDataGridRow,1].ToString().Trim();
			textBoxAuthor.Text=dataGrid[iDataGridRow,2].ToString().Trim();
			textBoxTopic.Text=dataGrid[iDataGridRow,4].ToString().Trim();
			textBoxPage.Text=dataGrid[iDataGridRow,3].ToString().Trim();
			textBoxCode.Text=dataGrid[iDataGridRow,5].ToString().Trim();

		}


		
		

		private void menuItemAdd_Click(object sender, System.EventArgs e)
		{
			AddData();
		}

		private void menuItemDelete_Click(object sender, System.EventArgs e)
		{
			DeleteData();
		}

		private void menuItemexit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void menuItemModify_Click(object sender, System.EventArgs e)
		{
			ModifyData();
		}

		private void menuItemSearch_Click(object sender, System.EventArgs e)
		{
			SearchData();
		}

		private void menuItemreload_Click(object sender, System.EventArgs e)
		{
			LoadData();
		}

		private void timer_Tick(object sender, System.EventArgs e)
		{
			statusBar.Panels[1].Text=System.DateTime.Today.ToShortDateString();
		}

		private void menuCreateDatabase_Click(object sender, System.EventArgs e)
		{
			CreateDatabase();
		}


		public void CreateDatabase()
		{	
			string sCreateDatabase="CREATE DATABASE Library";			
			string sCreateTable="CREATE TABLE Books (BookID INTEGER PRIMARY KEY IDENTITY,"+
				"Title CHAR(50) NOT NULL , Author CHAR(50), PageCount INTEGER,Topic CHAR(30),Code CHAR(15))" ; 
			string sInsertFirstRow="INSERT INTO BOOKS (TITLE,AUTHOR,PAGECOUNT,TOPIC,CODE)" 
				+"VALUES('Test Book','Test Author', 100, 'Test Topic', 'Test Code');";
			
			SqlConnection mycon=new SqlConnection();
			mycon.ConnectionString="workstation id=;initial catalog=; integrated security=SSPI";

			SqlCommand mycomm=new SqlCommand();
			mycomm.CommandType=CommandType.Text;
			mycomm.CommandText=sCreateDatabase;
			mycomm.Connection=mycon;

			try
			{
			
				mycon.Open();
	
				mycomm.ExecuteNonQuery();
			}
			catch
			{
				
				MessageBox.Show(" The database already exists. ");
			}	
			finally
			{
				mycon.Close();
			}
				
			mycon.ConnectionString="workstation id=;initial catalog=Library; integrated security=SSPI";
			try
			{
				
				mycon.Open();
				
				mycomm.CommandText=sCreateTable;
				mycomm.ExecuteNonQuery();
				
				mycomm.CommandText=sInsertFirstRow;
				mycomm.ExecuteNonQuery();
			}
			catch
			{
				MessageBox.Show(" There is already a table named 'Books' in the database. ");
			}
			finally
			{
				mycon.Close();
			}
		}	
	}
	
	public class dataManipulationClass
	{
		public SqlConnection mycon;
		public DataSet myds;
		public DataTable mytable;
		public SqlDataAdapter myadap;
		public SqlCommand mycomm;		

		public bool ManupulateData()
		{
			mycon=new SqlConnection();
			mycon.ConnectionString="workstation id=;initial catalog=LIBRARY; integrated security=SSPI";
					
			myds=new DataSet();
			mytable=new DataTable("books");
			myds.Tables.Add(mytable);
			myadap=new SqlDataAdapter();

			mycomm=new SqlCommand();
			mycomm.CommandType=CommandType.Text;
			mycomm.CommandText="SELECT BOOKID, TITLE,AUTHOR,PAGECOUNT,TOPIC,CODE FROM BOOKS";
			mycomm.Connection=mycon;
			myadap.SelectCommand=mycomm;

			return true;
		}
	}
	
}
